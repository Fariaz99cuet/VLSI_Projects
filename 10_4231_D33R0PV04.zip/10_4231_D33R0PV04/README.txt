Purdue Nanoelectronics Research Laboratory Magnetic Tunnel Junction Model
 Version 1.0.0
 Authors: 
 Xuanyao Fong, Purdue University
 Sri Harsha Choday, Purdue University
 Panagopoulos Georgios, Purdue University
 Charles Augustine, Purdue University
 Kaushik Roy, Purdue University
 doi:10.4231/D33R0PV04
 
 
 License: 
 NEEDS Modified CMC License
 Copyright @ 2014 Purdue University
The terms under which the software and associated documentation (the Software) is provided are as the following:
The Software is provided "as is", without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose and noninfringement. In no event shall the authors or copyright holders be liable for any claim, damages or other liability, whether in an action of contract, tort or otherwise, arising from, out of or in connection with the Software or the use or other dealings in the Software.
The authors or copyright holders grants, free of charge, to any users the right to modify, copy, and redistribute the Software, both within the user's organization and externally, subject to the following restrictions:
1. The users agree not to charge for the code itself but may charge for additions, extensions, or support.
2. In any product based on the Software, the users agree to acknowledge the Research Group that developed the software. This acknowledgment shall appear in the product documentation.
3. The users agree to obey all U.S. Government restrictions governing redistribution or export of the software.
4. The users agree to reproduce any copyright notice which appears on the software on any copy or modification of such made available to others.
Agreed to by 
Kaushik Roy
June 20, 2014
 
 #####################################
 Included Publication Materials:
 #####################################
 
Verilog-A Source Code: 
>>> needsmtj_1_0_0b.va

Circuit simulation benchmark files: 
>>> Benchmarks/needsmtj_1_0_0b_test_bench.zip

Parameter Sets/Extractor: 
>>> Parameters/needsmtj_1_0_0b_parameters.txt.sp

Manual: 
>>> Manual/needsmtj_1_0_0b_manual.pdf

Other Files: 
>>> Miscellaneous/needsmtj_1_0_0b_parameter_extractor_Matlab.zip

License File: 
>>> LICENSE.txt

Archival Info:
>>> README.txt

 
 --------------------------------------------
 Archival package produced 2018-08-06 12:14:23